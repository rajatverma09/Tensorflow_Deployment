import pandas as pd
import json
import sys
import requests

test_data = sys.argv[1]

test_data = pd.read_csv(test_data)
test_data = test_data.iloc[1:,:-1]

request_str = {"signature_name": "predict","instances":[]}
# t_dic = {"sepal_length":None, "sepal"}
i = 0
print(test_data.columns)
for index,row in test_data.iterrows():
	if i == 0:
		i += 1
		continue

	temp = {"sepal_length":[row["sepal length"]],"sepal_width":[row["sepal width"]],"petal_length":[row["petal ength"]],"petal_width":list(row["petal width"])}
	request_str['instances'].append(temp)
	if i == 2:
		break

# request_str += ']}'
# print("************************")
print(request_str)
data = json.dumps(request_str)
# print(data)
headers = {"content-type": "application/json"}
json_response = requests.post('http://localhost:8501/v1/models/iris:predict', data=data, headers=headers)
print (json_response.text)
