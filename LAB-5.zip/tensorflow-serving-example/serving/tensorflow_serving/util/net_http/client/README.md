The client library is still under development, and currently used for writing tests.

The API specs are yet to be finalized.